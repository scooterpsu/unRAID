**scriptRunner**

This plugin runs scripts when system events are triggered